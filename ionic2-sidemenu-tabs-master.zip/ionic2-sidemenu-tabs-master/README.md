# Ionic 2 Side Menu + Tabs

## What is here?

[Ionic 2 Final](http://blog.ionic.io/announcing-ionic-2-0-0-final/) is here, and this project has been updated to reflect that. See the [related blog post on Khophi's Dev](https://blog.khophi.co/ionic-2-side-menu-tabs/) for more details

Screenshot:
[![ionic 2 sidemenu tabs][2]][2]
[2]: http://i.stack.imgur.com/JfbVb.png

Test it out locally
- Clone this repo
- `npm install`
- `ionic serve -l`

Get ionized!
